import React, { useRef, useState, useEffect } from 'react';
import { Trash2 } from 'lucide-react';

interface DrawingCanvasProps {
  onSave: (base64: string) => void;
}

const DrawingCanvas: React.FC<DrawingCanvasProps> = ({ onSave }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasContent, setHasContent] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Set canvas resolution
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = 200; // Fixed height
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.strokeStyle = '#1e293b';
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
    }
  }, []);

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getPos(e, canvas);
    ctx.lineTo(x, y);
    ctx.stroke();
    if (!hasContent) setHasContent(true);
  };

  const stopDrawing = () => {
    if (isDrawing && hasContent && canvasRef.current) {
        onSave(canvasRef.current.toDataURL('image/png'));
    }
    setIsDrawing(false);
  };

  const getPos = (e: React.MouseEvent | React.TouchEvent, canvas: HTMLCanvasElement) => {
    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = (e as React.MouseEvent).clientX;
      clientY = (e as React.MouseEvent).clientY;
    }
    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    };
  };

  const clear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setHasContent(false);
      onSave(''); // Clear upstream
    }
  };

  return (
    <div className="relative w-full border border-slate-200 rounded-xl bg-white overflow-hidden touch-none">
      <canvas
        ref={canvasRef}
        className="w-full h-[200px] bg-slate-50 cursor-crosshair"
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={stopDrawing}
      />
      {hasContent && (
        <button 
          onClick={clear}
          className="absolute top-2 right-2 p-2 bg-white/80 backdrop-blur rounded-full shadow-sm text-red-500 hover:bg-red-50"
        >
          <Trash2 size={16} />
        </button>
      )}
      <div className="absolute bottom-2 left-2 text-xs text-slate-400 pointer-events-none">
        Draw your note here
      </div>
    </div>
  );
};

export default DrawingCanvas;