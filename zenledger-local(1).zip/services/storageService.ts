
import { Entry, Category } from '../types';
import { STORAGE_KEY, CATEGORY_STORAGE_KEY, DEFAULT_EXPENSE_CATEGORIES } from '../constants';

// Helper for ID generation (fallback for non-secure contexts)
export const generateId = (): string => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  // Enhanced fallback with more randomness to prevent collisions
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
};

// --- Entries ---

export const getEntries = (): Entry[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    console.error("Failed to load entries", e);
    return [];
  }
};

export const getEntry = (id: string): Entry | undefined => {
  const entries = getEntries();
  return entries.find(e => e.id === id);
};

export const saveEntry = (entry: Entry): void => {
  try {
    const entries = getEntries();
    // Ensure we don't save duplicates if ID exists (safety check)
    const existingIndex = entries.findIndex(e => e.id === entry.id);
    let newEntries;
    
    if (existingIndex > -1) {
        entries[existingIndex] = entry;
        newEntries = entries;
    } else {
        newEntries = [entry, ...entries];
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(newEntries));
    window.dispatchEvent(new Event('zenledger-update'));
  } catch (e) {
    console.error("Failed to save entry", e);
    alert("Failed to save entry. Storage might be full.");
  }
};

export const updateEntry = (updatedEntry: Entry): void => {
  try {
    const entries = getEntries();
    const index = entries.findIndex(e => e.id === updatedEntry.id);
    
    if (index !== -1) {
      entries[index] = updatedEntry;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
      window.dispatchEvent(new Event('zenledger-update'));
    }
  } catch (e) {
    console.error("Failed to update entry", e);
    alert("保存失败");
  }
};

export const deleteEntry = (id: string): void => {
  if (!id) return;

  const entries = getEntries();
  
  // Use findIndex and splice instead of filter.
  // This ensures we only remove ONE entry, even if (hypothetically) multiple entries share the same ID.
  // This fixes the "deleted all records" bug caused by ID collisions.
  const index = entries.findIndex(e => e.id === id);
  
  if (index !== -1) {
    entries.splice(index, 1);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    window.dispatchEvent(new Event('zenledger-update'));
  }
};

// --- Categories ---

export const getCategories = (): Category[] => {
  try {
    const data = localStorage.getItem(CATEGORY_STORAGE_KEY);
    if (data) return JSON.parse(data);
    
    // Initialize with defaults if empty
    localStorage.setItem(CATEGORY_STORAGE_KEY, JSON.stringify(DEFAULT_EXPENSE_CATEGORIES));
    return DEFAULT_EXPENSE_CATEGORIES as Category[];
  } catch (e) {
    return DEFAULT_EXPENSE_CATEGORIES as Category[];
  }
};

export const saveCategory = (category: Category): void => {
  const categories = getCategories();
  const newCategories = [...categories, category];
  localStorage.setItem(CATEGORY_STORAGE_KEY, JSON.stringify(newCategories));
  window.dispatchEvent(new Event('zenledger-categories-update'));
};

export const deleteCategory = (id: string): void => {
  const categories = getCategories();
  // Don't allow deleting the last category
  if (categories.length <= 1) return;
  
  const newCategories = categories.filter(c => c.id !== id);
  localStorage.setItem(CATEGORY_STORAGE_KEY, JSON.stringify(newCategories));
  window.dispatchEvent(new Event('zenledger-categories-update'));
};

// --- Backup & Restore ---

export const exportData = (): string => {
  const data = {
    entries: getEntries(),
    categories: getCategories(),
    exportedAt: new Date().toISOString(),
    appName: "ZenLedger",
    version: 1
  };
  return JSON.stringify(data, null, 2);
};

export const importData = (jsonString: string): boolean => {
  try {
    const data = JSON.parse(jsonString);
    
    // Simple validation structure check
    if (!data || !Array.isArray(data.entries) || !Array.isArray(data.categories)) {
      console.error("Invalid backup file format");
      return false;
    }

    // Restore Data
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data.entries));
    localStorage.setItem(CATEGORY_STORAGE_KEY, JSON.stringify(data.categories));

    // Trigger updates across the app
    window.dispatchEvent(new Event('zenledger-update'));
    window.dispatchEvent(new Event('zenledger-categories-update'));
    
    return true;
  } catch (e) {
    console.error("Import failed", e);
    return false;
  }
};
