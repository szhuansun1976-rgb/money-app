/**
 * Service disabled for local privacy-focused version.
 * This file is kept as a stub to prevent import errors if it's referenced elsewhere.
 */

export const parseTransaction = async (input: string): Promise<any | null> => {
  return null;
};

export const generateInsights = async (entries: any[]): Promise<string> => {
  return "Local version - AI disabled";
};